import React, { useState } from 'react'
import Aheader from '../Component/Aheader'
import Afooter from '../Component/Afooter'
import { toast } from 'react-toastify'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

function Add_team() {

    const [form, setform] = useState({
        name: "",
        instaid: "",
        facebook: "",
        image: "",
        expert: ""
    })

    const redirect = useNavigate()
    const viewteam = () => {
        redirect('/manage_team');
    }


    const changehandle = (e) => {
        setform({ ...form, id: new Date().getMilliseconds().toString(), status: "unblock", [e.target.name]: e.target.value });
        console.log(form);
    }

    function validation() {
        let ans = true;
        if (form.name === "") {
            toast.error("Name is required");
            ans = false;
        }
        if (form.image === "") {
            toast.error("Image is required");
            ans = false;
        }
        return ans;
    }

    const submitteam = async (e) => {
        e.preventDefault();
        if (validation()) {
            try {
                const response = await axios.post(`http://localhost:3000/team`, form);
                setform({ name: "", instaid: "", facebook: "", image: "", expert: "" });
                toast.success('Team added successfully');
            } catch (error) {
                toast.error('Failed to add team');
            }
        }
    }

    return (
        <div>
            <Aheader title={'Add Our Team Member'} />
            <div className="container-fluid">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="bg-light p-lg-5">
                                <h6 className="d-inline-block text-white text-uppercase bg-primary py-1 px-2">Our Team</h6>
                                <button className='btn btn-info ml-5' onClick={viewteam} style={{ float: 'right', marginRight: '50px' }}>View Our Team</button>
                                <h1 className="mb-4">Add Our Team</h1>
                                <form method='post' onSubmit={submitteam} name="sentMessage" id="contactForm">
                                    <div className="form-row">
                                        <div className="col-sm-12 control-group">
                                            <input type="text" onChange={changehandle} value={form.name} className="form-control border-0 p-4" name='name' id="name" placeholder="Your Name" />
                                            <p className="help-block text-danger" />
                                        </div>
                                        <div className="col-sm-12 control-group">
                                            <input type="text" onChange={changehandle} value={form.expert} className="form-control border-0 p-4" name='expert' id="expert" placeholder="Your Expert" />
                                            <p className="help-block text-danger" />
                                        </div>
                                        <div className="col-sm-12 control-group">
                                            <input type="text" onChange={changehandle} value={form.instaid} className="form-control border-0 p-4" name='instaid' id="instaid" placeholder="Your Insta Link" />
                                            <p className="help-block text-danger" />
                                        </div>
                                        <div className="col-sm-12 control-group">
                                            <input type="text" onChange={changehandle} value={form.facebook} className="form-control border-0 p-4" name='facebook' id="facebook" placeholder="Your Facebook Link" />
                                            <p className="help-block text-danger" />
                                        </div>
                                        <div className="col-sm-12 control-group">
                                            <input type="url" onChange={changehandle} value={form.image} className="form-control border-0 p-4" name='image' id="image" placeholder="Your Image Link" />
                                            <p className="help-block text-danger" />
                                        </div>
                                    </div>
                                    <div>
                                        <button className="btn btn-primary py-3 px-4" type="submit" id="sendMessageButton">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Afooter />
        </div>
    )
}

export default Add_team
