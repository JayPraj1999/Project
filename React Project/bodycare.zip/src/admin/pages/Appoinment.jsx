import React, { useEffect, useState } from 'react'
import Aheader from '../Component/Aheader'
import Afooter from '../Component/Afooter'
import axios from 'axios';
import { toast } from 'react-toastify';

function Appointment() {
    const [appointments, setAppointments] = useState([]);
    const [categories, setCategories] = useState([]);
    const [services, setServices] = useState([]);

    useEffect(() => {
        fetchAppointments();
        fetchCategories();
        fetchServices();
    }, []);

    const fetchAppointments = async () => {
        try {
            const res = await axios.get('http://localhost:3000/appointment');
            setAppointments(res.data);
        } catch (error) {
            toast.error('Error fetching appointments');
        }
    }

    const fetchCategories = async () => {
        try {
            const res = await axios.get('http://localhost:3000/categories');
            setCategories(res.data);
        } catch (error) {
            toast.error('Error fetching categories');
        }
    }

    const fetchServices = async () => {
        try {
            const res = await axios.get('http://localhost:3000/service');
            setServices(res.data);
        } catch (error) {
            toast.error('Error fetching services');
        }
    }

    const deleteAppointment = async (id) => {
        try {
            await axios.delete(`http://localhost:3000/appointment/${id}`);
            toast.success('Delete success');
            fetchAppointments(); // Refresh the list after deletion
        } catch (error) {
            toast.error('Error deleting appointment');
        }
    }

    const getCategoryName = (id) => {
        const category = categories.find(cat => cat.id === id);
        return category ? category.title : 'Unknown';
    }

    const getServiceName = (id) => {
        const service = services.find(ser => ser.id === id);
        return service ? service.service_name : 'Unknown';
    }

    const toggleStatus = async (id, currentStatus) => {
        const newStatus = currentStatus === "approved" ? "pending" : "approved";
        try {
            await axios.patch(`http://localhost:3000/appointment/${id}`, { status: newStatus });
            toast.success(`Status changed to ${newStatus}`);
            fetchAppointments(); // Refresh the list after status update
        } catch (error) {
            toast.error('Error updating status');
        }
    }

    return (
        <div>
            <Aheader title={"Appointment"} />
            <div className="container-fluid">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="bg-light p-lg-5">
                                <h1 className="mb-4">Manage Appointment</h1>
                                <div id="success" />
                                <table className="table">
                                    <thead className="table-dark">
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Date</th>
                                            <th>Time</th>
                                            <th>Categories</th>
                                            <th>Services</th>
                                            <th>Action</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {appointments && appointments.map((appointment) => (
                                            <tr key={appointment.id}>
                                                <td>{appointment.id}</td>
                                                <td>{appointment.name}</td>
                                                <td>{appointment.email}</td>
                                                <td>{appointment.date}</td>
                                                <td>{appointment.time}</td>
                                                <td>{getCategoryName(appointment.category)}</td>
                                                <td>{getServiceName(appointment.service)}</td>
                                                <td>
                                                    <button className='btn btn-danger' onClick={() => deleteAppointment(appointment.id)}>Delete</button>
                                                </td>
                                                <td>
                                                    <button
                                                        className={`btn ${appointment.status === "approved" ? 'btn-success' : 'btn-secondary'}`}
                                                        onClick={() => toggleStatus(appointment.id, appointment.status)}
                                                    >
                                                        {appointment.status === "pending" ? 'Pending' : 'Approved'}
                                                    </button>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Afooter />
        </div>
    )
}

export default Appointment;
