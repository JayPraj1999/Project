import React, { useEffect, useState } from 'react'
import Aheader from '../Component/Aheader'
import Afooter from '../Component/Afooter'
import axios from 'axios';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';

function Manage_Team() {

    const redirect = useNavigate();
    const addteam = () => {
        redirect('/add_team')
    }

    // data get code 
    const [data, setdata] = useState([]);

    useEffect(() => {
        gettem();
    }, [])

    const gettem = async () => {
        const res = await axios.get(`http://localhost:3000/team`);
        setdata(res.data);
    }

    // data delete code
    const deleteteam = async (id) => {
        await axios.delete(`http://localhost:3000/team/${id}`);
        toast.success("Deleted Successfully");
        gettem(); // Refresh the list after deletion
    }

    // edit code  
    const [form, setForm] = useState({
       
        name: "",
        instaid: "",
        facebook: "",
        image: "",
        expert: "",
        status: "" // Added status to the form
    })

    const edithandel = async (id) => {
        const res = await axios.get(`http://localhost:3000/team/${id}`);
        setForm(res.data);
        document.getElementById('myModal').style.display = "block";
    }

    const changeHandle = (e) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    }

    function validation() {
        let ans = true;
        if (form.name === "") {
            toast.error("Name is required");
            ans = false;
        }
        if (form.image === "") {
            toast.error("Image is required");
            ans = false;
        }
        return ans;
    }

    const submitHandle = async (e) => {
        e.preventDefault();
        if (validation()) {
            await axios.patch(`http://localhost:3000/team/${form.id}`, form);
            setForm({ ...form, name: "", instaid: "", facebook: "", image: "", expert: "", status: "" });
            document.getElementById('myModal').style.display = "none";
            toast.success('Member Updated successfully');
            gettem(); // Refresh the list after update
        }
    }

    // Status toggle code
    const toggleStatus = async (id, currentStatus) => {
        const newStatus = currentStatus === "Active" ? "Inactive" : "Active";
        await axios.patch(`http://localhost:3000/team/${id}`, { status: newStatus });
        toast.success(`Status changed to ${newStatus}`);
        gettem(); // Refresh the list after status change
    }

    return (
        <>
            <Aheader title={'Manage Our Team'} />
            <div className="container-fluid">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="bg-light p-lg-5">
                                <h1 className="d-inline-block text-white text-uppercase bg-primary py-1 px-2 mb-4">Manage Team</h1>
                                <button className='btn btn-info ml-5' onClick={addteam} style={{ float: 'right', marginRight: '50px' }}>Add Team Member</button>
                                <table className="table">
                                    <thead className="table-dark">
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Expert</th>
                                            <th>Insta Id</th>
                                            <th>FaceBook Id</th>
                                            <th>Image</th>
                                            <th>Action</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {data && data.map((value) => (
                                            <tr key={value.id}>
                                                <td>{value.id}</td>
                                                <td>{value.name}</td>
                                                <td>{value.expert}</td>
                                                <td>{value.instaid}</td>
                                                <td>{value.facebook}</td>
                                                <td><img src={value.image} alt="" height={50} /></td>
                                                <td>
                                                    <button className='btn btn-info mr-2' onClick={() => edithandel(value.id)} >Edit</button>
                                                    <button className='btn btn-danger' onClick={() => deleteteam(value.id)}>Delete</button>
                                                </td>
                                                <td>
                                                    <button className={`btn ${value.status === "Active" ? 'btn-success' : 'btn-secondary'}`} onClick={() => toggleStatus(value.id, value.status)}>
                                                        {value.status}
                                                    </button>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>

                                {/* edit code  */}
                                <div className="modal" id="myModal">
                                    <div className="modal-dialog">
                                        <div className="modal-content">
                                            <div className="modal-header">
                                                <h4 className="modal-title">Edit Member</h4>
                                                <button type="button" className="close" data-dismiss="modal">×</button>
                                            </div>
                                            <div className="modal-body">
                                                <form method='post' name="sentMessage" id="contactForm" noValidate="novalidate">
                                                    <div className="form-row">
                                                        <div className="col-sm-12 control-group">
                                                            <input name="name" type="text" value={form.name} onChange={changeHandle} className="form-control border-0 p-4" id="name" placeholder="Team Member Name" required="required" />
                                                            <p className="help-block text-danger" />
                                                        </div>
                                                        <div className="col-sm-12 control-group">
                                                            <input name="expert" type="text" value={form.expert} onChange={changeHandle} className="form-control border-0 p-4" id="expert" placeholder="Team Member Expert" required="required" />
                                                            <p className="help-block text-danger" />
                                                        </div>
                                                        <div className="col-sm-12 control-group">
                                                            <input name="instaid" type="url" value={form.instaid} onChange={changeHandle} className="form-control border-0 p-4" id="instaid" placeholder="Team Member Insta" required="required" />
                                                            <p className="help-block text-danger" />
                                                        </div>
                                                        <div className="col-sm-12 control-group">
                                                            <input name="facebook" type="url" value={form.facebook} onChange={changeHandle} className="form-control border-0 p-4" id="facebook" placeholder="Team Member Facebook" required="required" />
                                                            <p className="help-block text-danger" />
                                                        </div>
                                                        <div className="col-sm-12 control-group">
                                                            <input name="image" type="url" value={form.image} onChange={changeHandle} className="form-control border-0 p-4" id="image" placeholder="Team Member Image" required="required" />
                                                            <p className="help-block text-danger" />
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <button className="btn btn-primary py-3 px-4" onClick={submitHandle} type="submit" id="sendMessageButton">Submit</button>
                                                    </div>
                                                </form>
                                            </div>
                                            <div className="modal-footer">
                                                <button type="button" className="btn btn-danger" data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/* edit code end  */}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Afooter />
        </>
    )
}

export default Manage_Team;
