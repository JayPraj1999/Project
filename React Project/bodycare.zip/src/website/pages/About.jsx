import React from 'react';
import Header2 from '../Component/Header2';
import Footer from '../Component/Footer';
import CountUp from 'react-countup';

function About() {
    return (
        <div>
            <Header2 title="About Us"/>
            {/* About Start */}
            <div className="container-fluid py-5">
                <div className="container py-5">
                    <div className="row align-items-center">
                        <div className="col-lg-6 pb-5 pb-lg-0">
                            <img className="img-fluid w-100" src="website/img/about.jpg" alt="About Us" />
                        </div>
                        <div className="col-lg-6">
                            <h6 className="d-inline-block text-primary text-uppercase bg-light py-1 px-2">About Us</h6>
                            <h1 className="mb-4">Your Best Spa, Beauty &amp; Skin Care Center</h1>
                            <p className="pl-4 border-left border-primary">Welcome to Rajvi Clinic & Cosmetic, where we blend luxury, relaxation, and advanced skincare treatments to provide you with the ultimate spa experience. Our mission is to help you achieve optimal well-being and enhance your natural beauty through personalized services and state-of-the-art technology.</p>
                            <div className="row pt-3">
                                <div className="col-6">
                                    <div className="bg-light text-center p-4">
                                        <h3 className="display-4 text-primary">
                                            <CountUp start={0} end={10} duration={3} />
                                        </h3>
                                        <h6 className="text-uppercase">Spa Specialist</h6>
                                    </div>
                                </div>
                                <div className="col-6">
                                    <div className="bg-light text-center p-4">
                                        <h3 className="display-4 text-primary">
                                            <CountUp start={0} end={550} duration={3}/>
                                        </h3>
                                        <h6 className="text-uppercase">Happy Clients</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    

                    {/* Testimonials Section */}
                    <div className="row pt-5">
                        <div className="col-lg-12">
                            <h2 className="text-center mb-5">Testimonials</h2>
                        </div>
                        <div className="col-lg-4">
                            <div className="bg-light text-center p-4">
                                <p>"Rajvi Clinic & Cosmetic is the best spa I have ever visited. Their services are exceptional and the staff is very friendly. Highly recommended!"</p>
                                <h6 className="text-uppercase">- Sarah Johnson</h6>
                            </div>
                        </div>
                        <div className="col-lg-4">
                            <div className="bg-light text-center p-4">
                                <p>"I love coming here for my skincare treatments. They always make me feel pampered and my skin has never looked better!"</p>
                                <h6 className="text-uppercase">- Emily Brown</h6>
                            </div>
                        </div>
                        <div className="col-lg-4">
                            <div className="bg-light text-center p-4">
                                <p>"Amazing spa with top-notch services. The massage therapist is excellent and really helps me relax and unwind."</p>
                                <h6 className="text-uppercase">- Michael Davis</h6>
                            </div>
                        </div>
                    </div>

                    {/* Services Section */}
                    <div className="row pt-5">
                        <div className="col-lg-12">
                            <h2 className="text-center mb-5">Our Services</h2>
                        </div>
                        <div className="col-lg-4">
                            <div className="bg-light text-center p-4">
                                <h5 className="mb-3">Facials</h5>
                                <p>Our facials are designed to rejuvenate and refresh your skin, leaving you with a radiant complexion.</p>
                            </div>
                        </div>
                        <div className="col-lg-4">
                            <div className="bg-light text-center p-4">
                                <h5 className="mb-3">Massage Therapy</h5>
                                <p>Experience ultimate relaxation with our massage therapy services, tailored to relieve stress and tension.</p>
                            </div>
                        </div>
                        <div className="col-lg-4">
                            <div className="bg-light text-center p-4">
                                <h5 className="mb-3">Body Treatments</h5>
                                <p>Our body treatments are designed to exfoliate, hydrate, and nourish your skin, giving you a healthy glow.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* About End */}
            <Footer/>
        </div>
    );
}

export default About;
