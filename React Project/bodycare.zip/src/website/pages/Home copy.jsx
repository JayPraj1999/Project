import React, { useEffect, useState } from 'react';
import Header1 from '../Component/Header1';
import Footer from '../Component/Footer';
import { Helmet } from 'react-helmet';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Home() {
  const [categories, setCategories] = useState([]);
  const [services, setServices] = useState([]);
  const [filteredServices, setFilteredServices] = useState([]); // New state for filtered services
  const [selectedCategory, setSelectedCategory] = useState(null); // New state for selected category

  useEffect(() => {
    const fetchData = async () => {
      try {
        const categoriesRes = await axios.get('http://localhost:3000/categories');
        setCategories(categoriesRes.data);

        const servicesRes = await axios.get('http://localhost:3000/service');
        setServices(servicesRes.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  const handleCategoryChange = (event) => {
    const categoryId = event.target.value;
    setSelectedCategory(categoryId);

    // Filter services based on selected category
    const filtered = services.filter((service) => service.cat_id === categoryId);
    setFilteredServices(filtered);
  };

  return (
    <div>
      <Header1 />
      {/* About Start */}
      {/* ... (About section remains the same) ... */}
      {/* About End */}

      {/* Service Start */}
      <div className="container-fluid px-0 py-5 my-5">
        <div className="row mx-0 justify-content-center text-center">
          <div className="col-lg-6">
            <h6 className="d-inline-block bg-light text-primary text-uppercase py-1 px-2">Our Service</h6>
            <h1>Spa &amp; Beauty Services</h1>
          </div>
        </div>

        <div className="row justify-content-center bg-appointment mx-0">
          <div className="col-lg-6 py-5">
            <div className="p-5 my-5" style={{ background: 'rgba(33, 30, 28, 0.7)' }}>
              <h1 className="text-white text-center mb-4">Make Appointment</h1>
              <form>
                {/* ... (Appointment form remains the same) ... */}
                <div className="form-row">
                  <div className="col-sm-6">
                    <div className="form-group">
                      <select className="custom-select bg-transparent px-4" style={{ height: 47 }} onChange={handleCategoryChange}>
                        <option value="">Select Category</option>
                        {categories.map((category) => (
                          <option key={category.id} value={category.id}>{category.title}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div className="col-sm-6">
                    <div className="form-group">
                      <select className="custom-select bg-transparent px-4" style={{ height: 47 }}>
                        <option value="">Select Service</option>
                        {filteredServices.map((service) => ( // Use filteredServices for dynamic service options
                          <option key={service.id} value={service.id}>{service.service_name}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div className="col-sm-6">
                    <button className="btn btn-primary btn-block" type="submit" style={{ height: 47 }}>Make Appointment</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      {/* Service End */}

      {/* Team Start */}
      {/* ... (Team section remains the same) ... */}
      {/* Team End */}

      <Helmet>
        {/* ... (Helmet section remains the same) ... */}
      </Helmet>

      <Footer />
    </div>
  );
}

export default Home;