import React, { useEffect, useState } from 'react';
import Header1 from '../Component/Header1';
import Footer from '../Component/Footer';
import { Helmet } from 'react-helmet';
import axios from 'axios';
import $ from 'jquery';
import 'tempusdominus-bootstrap-4/build/js/tempusdominus-bootstrap-4.min.js';
import moment from 'moment';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';

function Home() {
  const redirect = useNavigate();

  const gotologin = () => {
    redirect('/login');
    toast.success("Please log in to make an appointment.");
  }
  

    const [categories, setCategories] = useState([]);
    const [services, setServices] = useState([]);
    const [filteredServices, setFilteredServices] = useState([]);
    const [selectedCategory, setSelectedCategory] = useState(null);

    const [form, setForm] = useState({
        name: "",
        email: "",
        date: "",
        time: "",
        category: "",
        service: "",
        status:""
    });

    useEffect(() => {
        window.$ = window.jQuery = $;
        fetchTeam();
        fetchCategories();
        fetchServices();
    }, []);

    const [data, setData] = useState([]);

    const fetchTeam = async () => {
        try {
            const res = await axios.get('http://localhost:3000/team');
            setData(res.data);
        } catch (error) {
            console.error('Error fetching team:', error);
        }
    };

    const fetchCategories = async () => {
        try {
            const res = await axios.get('http://localhost:3000/categories');
            setCategories(res.data);
        } catch (error) {
            console.error('Error fetching categories:', error);
        }
    };

    const fetchServices = async () => {
        try {
            const res = await axios.get('http://localhost:3000/service');
            setServices(res.data);
        } catch (error) {
            console.error('Error fetching services:', error);
        }
    };

    const handleCategoryChange = (event) => {
        const categoryId = event.target.value;
        setSelectedCategory(categoryId);

        // Filter services based on selected category
        const filtered = services.filter((service) => service.cat_id === categoryId);
        setFilteredServices(filtered);
        setForm({ ...form, category: categoryId, service: "" }); // Update form state with selected category
    };

    const handleInputChange = (e) => {
        setForm({ ...form, status: "panding", [e.target.name]: e.target.value });
    };

    const validateForm = () => {
        if (!form.name) {
            toast.error("Please enter your name");
            return false;
        }
        if (!form.email) {
            toast.error("Please enter your email");
            return false;
        }
        if (!form.date) {
            toast.error("Please enter your date");
            return false;
        }
        if (!form.time) {
            toast.error("Please enter your time");
            return false;
        }
        if (!form.category) {
            toast.error("Please select a category");
            return false;
        }
        if (!form.service) {
            toast.error("Please select a service");
            return false;
        }
        return true;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (validateForm()) {
            try {
                const res = await axios.post('http://localhost:3000/appointment', form);
                setForm({ name: "", email: "", date: "", time: "", category: "", service: "",status:"" });
                toast.success("Appointment made successfully");
            } catch (error) {
                toast.error("Error making appointment");
            }
        }
    };

    return (
        <div>
            <Header1 />
            {/* About Start */}
            <div className="container-fluid py-5">
                <div className="container py-5">
                    <div className="row align-items-center">
                        <div className="col-lg-6 pb-5 pb-lg-0">
                            <img className="img-fluid w-100" src="website/img/about.jpg" alt="About" />
                        </div>
                        <div className="col-lg-6">
                            <h6 className="d-inline-block text-primary text-uppercase bg-light py-1 px-2">
                                About Rajvi Clinic & Cosmetic
                            </h6>
                            <h1 className="mb-4">Your Best Spa, Beauty &amp; Skin Care Center</h1>
                            <p className="pl-4 border-left border-primary">
                                Rajvi Clinic & Cosmetic is dedicated to providing exceptional healthcare and aesthetic services. Our clinic is equipped with state-of-the-art technology and staffed by highly trained professionals committed to delivering personalized and compassionate care. At Rajvi Clinic & Cosmetic, we offer a wide range of medical and cosmetic treatments designed to meet the unique needs of each patient.
                            </p>
                            <div className="row pt-3">
                                <div className="col-6">
                                    <div className="bg-light text-center p-4">
                                        <h3 className="display-4 text-primary" data-toggle="counter-up">99</h3>
                                        <h6 className="text-uppercase">Spa Specialist</h6>
                                    </div>
                                </div>
                                <div className="col-6">
                                    <div className="bg-light text-center p-4">
                                        <h3 className="display-4 text-primary" data-toggle="counter-up">999</h3>
                                        <h6 className="text-uppercase">Happy Clients</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* About End */}

            {/* Service Start */}
            <div className="container-fluid px-0 py-5 my-5">
                <div className="row mx-0 justify-content-center text-center">
                    <div className="col-lg-6">
                        <h6 className="d-inline-block bg-light text-primary text-uppercase py-1 px-2">Our Service</h6>
                        <h1>Spa &amp; Beauty Services</h1>
                    </div>  
                </div>
                <div className="row justify-content-center bg-appointment mx-0">
                    <div className="col-lg-6 py-5">
                        <div className="p-5 my-5" style={{ background: 'rgba(33, 30, 28, 0.7)' }}>
                            <h1 className="text-white text-center mb-4">Make Appointment</h1>
                            <form method='post' onSubmit={handleSubmit}>
                                <div className="form-row">
                                    <div className="col-sm-6">
                                        <div className="form-group">
                                            <input type="text" onChange={handleInputChange} value={form.name} className="form-control p-4" name='name' placeholder="Your Name" required />
                                        </div>
                                    </div>
                                    <div className="col-sm-6">
                                        <div className="form-group">
                                            <input type="email" onChange={handleInputChange} value={form.email} className="form-control p-4" name='email' placeholder="Your Email" required />
                                        </div>
                                    </div>
                                </div>
                                <div className="form-row">
                                    <div className="col-sm-6">
                                        <div className="form-group">
                                            <div className="date" id="date" data-target-input="nearest">
                                                <input type="date" onChange={handleInputChange} value={form.date} className="form-control p-4" name='date' placeholder="Select Date" data-target="#date"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-sm-6">
                                        <div className="form-group">
                                            <div className="time" id="time" data-target-input="nearest">
                                                <input type="time" onChange={handleInputChange} value={form.time} className="form-control p-4" name='time' placeholder="Select Time" data-target="#time"/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="form-row">
                                    <div className="col-sm-6">
                                        <div className="form-group">
                                            <select className="custom-select px-4" value={form.category} name='category' style={{ height: 47 }} onChange={handleCategoryChange}>
                                                <option value="">Select Category</option>
                                                {categories.map(category => (
                                                    <option key={category.id} value={category.id}>{category.title}</option>
                                                ))}
                                            </select>
                                        </div>
                                    </div>
                                    <div className="col-sm-6">
                                        <div className="form-group">
                                            <select className="custom-select px-4" value={form.service} onChange={handleInputChange} name='service' style={{ height: 47 }}>
                                                <option value="">Select Service</option>
                                                {filteredServices.map(service => (
                                                    <option key={service.id} value={service.id}>{service.service_name}</option>
                                                ))}
                                            </select>
                                        </div>
                                    </div>
                                    <div className="col-sm-6">
                                        {(()=> {
                                            if(localStorage.getItem('uid')){
                                                return(
                                       <button className="btn btn-primary btn-block" type="submit" style={{ height: 47 }}>Make Appointment</button>
                                                )
                                            }
                                            else{
                                                return(
                                            <button className="btn btn-primary btn-block" onClick={gotologin} type="submit" style={{ height: 47 }}>Make Appointment</button>
                                                )
                                            }
                                        }

                                        )()}
                                        
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            {/* Service End */}

            {/* Team Start */}
            <div className="container-fluid py-5">
                <div className="container pt-5">
                    <div className="row justify-content-center text-center">
                        <div className="col-lg-6">
                            <h6 className="d-inline-block bg-light text-primary text-uppercase py-1 px-2">Spa Specialist</h6>
                            <h1 className="mb-5">Spa &amp; Beauty Specialist</h1>
                        </div>
                    </div>
                    <div className="row">
                        {data && data.map((value) => (  
                            <div className="col-lg-3 col-md-6" key={value.id}>
                                <div className="team position-relative overflow-hidden mb-5">
                                    <img className="img-fluid" src={value.image} alt={value.name} style={{ height: '300px', objectFit: 'cover' }} />
                                    <div className="position-relative text-center">
                                        <div className="team-text bg-primary text-white">
                                            <h5 className="text-white text-uppercase">{value.name}</h5>
                                            <p className="m-0">{value.expert}</p>
                                        </div>
                                        <div className="team-social bg-dark text-center">
                                            <a className="btn btn-outline-primary btn-square mr-2" href={value.twitter}><i className="fab fa-twitter" /></a>
                                            <a className="btn btn-outline-primary btn-square mr-2" href={value.facebook}><i className="fab fa-facebook-f" /></a>
                                            <a className="btn btn-outline-primary btn-square mr-2" href={value.linkedin}><i className="fab fa-linkedin-in" /></a>
                                            <a className="btn btn-outline-primary btn-square" href={value.instagram}><i className="fab fa-instagram" /></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
            {/* Team End */}

            <Helmet>
                <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
                <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
                <script src="/website/lib/easing/easing.min.js"></script>
                <script src="/website/lib/waypoints/waypoints.min.js"></script>
                <script src="/website/lib/counterup/counterup.min.js"></script>
                <script src="/website/lib/owlcarousel/owl.carousel.min.js"></script>
                <script src="/website/lib/tempusdominus/js/moment.min.js"></script>
                <script src="/website/lib/tempusdominus/js/moment-timezone.min.js"></script>
                <script src="/website/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
                <script src="/website/mail/jqBootstrapValidation.min.js"></script>
                <script src="/website/mail/contact.js"></script>
                <script src="/website/js/main.js"></script>
            </Helmet>

            <Footer />
        </div>
    );
}

export default Home;
