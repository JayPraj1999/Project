import React, { useEffect, useState } from 'react';
import Footer from '../Component/Footer';
import Header2 from '../Component/Header2';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';

function Login() {
    const redirect = useNavigate();

    useEffect(() => {
        if (localStorage.getItem('uid')) {
            redirect('/');
        }
    }, [redirect]);

    const [formvalue, setFormvalue] = useState({
        email: "",
        password: "",
    });

    const changeHandel = (e) => {
        setFormvalue({ ...formvalue, [e.target.name]: e.target.value });
    };

    function validation() {
        let isValid = true;
        if (formvalue.email === "") {
            toast.error("Email field is required");
            isValid = false;
        }
        if (formvalue.password === "") {
            toast.error("Password field is required");
            isValid = false;
        }
        return isValid;
    }

    const submitHandel = async (e) => {
        e.preventDefault();
        if (validation()) {
            try {
                const res = await axios.get(`http://localhost:3000/users?email=${formvalue.email}`);
                if (res.data.length > 0) {
                    const user = res.data[0];
                    if (user.password === formvalue.password) {
                        if (user.status === "Active") {

                            localStorage.setItem('uid', user.id);
                            localStorage.setItem('uname', user.name);
                            
                            toast.success('Login Successful');
                            redirect('/');
                        } else {    
                            toast.error('Your Account is Block. Please contact support.');
                        }
                    } else {
                        toast.error('Password is incorrect!');
                    }
                } else {
                    toast.error('Email does not exist!');
                }
            } catch (error) {
                toast.error('Error during login. Please try again.');
            }
        }
    };

    return (
        <>
            <Header2 title="Login Here" />
            <div className="container-fluid py-5">
                <div className="container py-5">
                    <div className="row">
                        <div className="col-lg-6" style={{ minHeight: 500 }}>
                            <div className="position-relative h-100">
                                <iframe
                                    className="position-absolute w-100 h-100"
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3001156.4288297426!2d-78.01371936852176!3d42.72876761954724!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4ccc4bf0f123a5a9%3A0xddcfc6c1de189567!2sNew%20York%2C%20USA!5e0!3m2!1sen!2sbd!4v1603794290143!5m2!1sen!2sbd"
                                    frameBorder={0}
                                    style={{ border: 0 }}
                                    allowFullScreen
                                    aria-hidden="false"
                                    tabIndex={0}
                                />
                            </div>
                        </div>
                        <div className="col-lg-6 pt-5 pb-lg-5">
                            <div className="contact-form bg-light p-4 p-lg-5 my-lg-5">
                                <h6 className="d-inline-block text-white text-uppercase bg-primary py-1 px-2">Login</h6>
                                <h1 className="mb-4">Login Here</h1>
                                <form id="contactForm" method='post' onSubmit={submitHandel}>
                                    <div className="form-row">
                                        <div className="col-sm-12 control-group">
                                            <input
                                                type="email"
                                                value={formvalue.email}
                                                onChange={changeHandel}
                                                className="form-control border-0 p-4"
                                                name="email"
                                                id="email"
                                                placeholder="Your Email"
                                            />
                                            <p className="help-block text-danger" />
                                        </div>
                                        <div className="col-sm-12 control-group">
                                            <input
                                                type="password"
                                                value={formvalue.password}
                                                onChange={changeHandel}
                                                className="form-control border-0 p-4"
                                                name="password"
                                                id="password"
                                                placeholder="Your Password"
                                            />
                                            <p className="help-block text-danger" />
                                        </div>
                                    </div>
                                    <div>
                                        <button className="btn btn-primary py-3 px-4" type="submit" id="sendMessageButton">Login</button>
                                        <Link to='/signup' className='float-right'>If you are not already registered then Sign Up Here</Link>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
        </>
    );
}

export default Login;
