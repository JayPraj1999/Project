import React, { useEffect, useState } from 'react'
import Header2 from '../Component/Header2'
import Footer from '../Component/Footer'
import { Helmet } from 'react-helmet'
import axios from 'axios';

function Ourteam() {

    const [data, setteamdata] = useState([]);

    useEffect(() => {
        teamfetch();
    }, []);

    const teamfetch = async () => {
        try {
            const res = await axios.get(`http://localhost:3000/team`);
            setteamdata(res.data);
        } catch (error) {
            console.error("Error fetching team data:", error);
        }
    };

    return (
        <div>
            <Header2 title="OurTeam"/>
            {/* Team Start */}
            <div className="container-fluid py-5">
                <div className="container pt-5">
                    <div className="row justify-content-center text-center">
                        <div className="col-lg-6">
                            <h6 className="d-inline-block bg-light text-primary text-uppercase py-1 px-2">Spa Specialist</h6>
                            <h1 className="mb-5">Spa &amp; Beauty Specialist</h1>
                        </div>
                    </div>
                    <div className="row">
                     {
                        data && data.length > 0 && data
                            .filter(member => member.status === 'Active')
                            .map((getValue) => {
                            return (
                                <div className="col-lg-3 col-md-6" key={getValue.id}>
                                    <div className="team position-relative overflow-hidden mb-5">
                                        <img className="img-fluid" src={getValue.image} alt={getValue.name} style={{ height: '300px', objectFit: 'cover' }} />
                                        <div className="position-relative text-center">
                                            <div className="team-text bg-primary text-white">
                                                <h5 className="text-white text-uppercase">{getValue.name}</h5>
                                                <p className="m-0">{getValue.expert}</p>
                                            </div>
                                            <div className="team-social bg-dark text-center">
                                                <a className="btn btn-outline-primary btn-square mr-2" href={getValue.twitter}><i className="fab fa-twitter" /></a>
                                                <a className="btn btn-outline-primary btn-square mr-2" href={getValue.facebook}><i className="fab fa-facebook-f" /></a>
                                                <a className="btn btn-outline-primary btn-square mr-2" href={getValue.linkedin}><i className="fab fa-linkedin-in" /></a>
                                                <a className="btn btn-outline-primary btn-square" href={getValue.instagram}><i className="fab fa-instagram" /></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )
                        })
                     }
                    </div>
                </div>
            </div>
            {/* Team End */}
            <Helmet>
                <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
                <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
                <script src="/website/lib/easing/easing.min.js"></script>
                <script src="/website/lib/waypoints/waypoints.min.js"></script>
                <script src="/website/lib/counterup/counterup.min.js"></script>
                <script src="/website/lib/owlcarousel/owl.carousel.min.js"></script>
                <script src="/website/lib/tempusdominus/js/moment.min.js"></script>
                <script src="/website/lib/tempusdominus/js/moment-timezone.min.js"></script>
                <script src="/website/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
                <script src="/website/mail/jqBootstrapValidation.min.js"></script>
                <script src="/website/mail/contact.js"></script>
                <script src="/website/js/main.js"></script>
            </Helmet>
            <Footer/>
        </div>
    )
}

export default Ourteam
